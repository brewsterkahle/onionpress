OnionPress backup
=================

This zip is an OnionPress site backup: the onion service key, the
WordPress database and wp-content, encrypted with the password
chosen when the backup was made. The encrypted data is
onionpress-backup.enc.

Made by OnionPress fixture.
To restore it, use that version or a newer one: Restore... in the
OnionPress menu, "Restore from backup..." on the welcome screen, or
`onionpress restore` on the command line. Versions from before
backup format 2 cannot read it and call it not a valid backup.

Format: OnionPress backup format 2 (libsodium: Argon2id,
XChaCha20-Poly1305 secretstream), specified in
src/onionpress/backup_crypto.py at
https://github.com/brewsterkahle/onionpress
